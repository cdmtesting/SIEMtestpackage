class MimecastEndpoints:
    get_siem_logs = '/api/audit/get-siem-logs'
    get_data_leak_protection_logs = '/api/dlp/get-logs'
